package com.boloenglish.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** Four dots. Still when idle, bouncing wave when listening/working. */
class DotsView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var animator: ValueAnimator? = null
    private var animating = false
    private val idleScale = floatArrayOf(0.85f, 1.2f, 1.2f, 0.85f)

    init {
        paint.color = Color.WHITE
    }

    fun setAnimating(on: Boolean) {
        if (on == animating) return
        animating = on
        animator?.cancel()
        animator = null
        if (on) {
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = 900
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            a.start()
            animator = a
        } else {
            invalidate()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w * 0.17f
        val base = w * 0.055f
        val startX = (w - gap * 3f) / 2f
        for (i in 0 until 4) {
            var r = base * idleScale[i]
            var dy = 0f
            if (animating) {
                val s = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat() - i * 0.9f)
                r = base * (0.8f + 0.7f * s)
                dy = -w * 0.06f * s
            }
            canvas.drawCircle(startX + gap * i, h / 2f + dy, r, paint)
        }
    }
}
