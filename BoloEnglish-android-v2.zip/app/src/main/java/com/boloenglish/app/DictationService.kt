package com.boloenglish.app

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class DictationService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()

    private var bubble: FrameLayout? = null
    private var dots: DotsView? = null
    private var recognizer: SpeechRecognizer? = null
    private var lastNode: AccessibilityNodeInfo? = null

    private var active = false
    private var working = 0
    private var errorCount = 0

    private var lastText = ""
    private var lastTextTime = 0L

    private val mutedStreams = ArrayList<Int>()
    private var models: List<String>? = null

    private val hideRunnable = Runnable {
        if (!active && working == 0) removeBubble()
    }
    private val restartRunnable = Runnable {
        if (active) listen()
    }
    private val unmuteRunnable = Runnable { unmuteBeep() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun prefs(): SharedPreferences = getSharedPreferences("prefs", MODE_PRIVATE)
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!::wm.isInitialized) return
        val focus: AccessibilityNodeInfo? = try {
            findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        } catch (e: Exception) {
            null
        }
        handler.removeCallbacks(hideRunnable)
        if (focus != null && focus.isEditable && !focus.isPassword) {
            lastNode = focus
            showBubble()
        } else {
            handler.postDelayed(hideRunnable, 700)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        unmuteBeep()
        removeBubble()
        pool.shutdownNow()
        super.onDestroy()
    }

    // ---------- Silence the start/stop beep ----------

    private fun muteBeep() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streams = intArrayOf(
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_SYSTEM
        )
        for (s in streams) {
            try {
                if (!am.isStreamMute(s)) {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    mutedStreams.add(s)
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun unmuteBeep() {
        if (mutedStreams.isEmpty()) return
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        for (s in mutedStreams) {
            try {
                am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
            }
        }
        mutedStreams.clear()
    }

    // ---------- Floating bubble (four dots) ----------

    private fun showBubble() {
        if (bubble != null) return
        val size = dp(56)
        val frame = FrameLayout(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(COLOR_IDLE)
        bg.setStroke(dp(2), Color.parseColor("#66FFFFFF"))
        frame.background = bg
        frame.elevation = dp(6).toFloat()
        frame.isSoundEffectsEnabled = false

        val d = DotsView(this)
        frame.addView(d, FrameLayout.LayoutParams(size, size))

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs().getInt("bx", dm.widthPixels - size - dp(8))
        lp.y = prefs().getInt("by", (dm.heightPixels * 0.35).toInt())
        frame.setOnTouchListener(dragListener(lp))

        try {
            wm.addView(frame, lp)
        } catch (e: Exception) {
            return
        }
        bubble = frame
        dots = d
        refreshState()
    }

    private fun removeBubble() {
        dots?.setAnimating(false)
        dots = null
        val b = bubble ?: return
        try {
            wm.removeView(b)
        } catch (e: Exception) {
        }
        bubble = null
    }

    private fun dragListener(lp: WindowManager.LayoutParams): View.OnTouchListener {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        return View.OnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) dragging = true
                    if (dragging) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        prefs().edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
                    } else {
                        onBubbleTap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshState() {
        val b = bubble ?: return
        val color = when {
            active -> COLOR_LISTENING
            working > 0 -> COLOR_WORKING
            else -> COLOR_IDLE
        }
        (b.background as? GradientDrawable)?.setColor(color)
        dots?.setAnimating(active || working > 0)
    }

    // ---------- Listening ----------

    private fun onBubbleTap() {
        if (active) {
            stopListening()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("पहले ऐप खोलकर माइक की अनुमति दें")
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("इस फोन में स्पीच रिकग्निशन उपलब्ध नहीं है")
            return
        }
        handler.removeCallbacks(unmuteRunnable)
        muteBeep()
        active = true
        errorCount = 0
        refreshState()
        listen()
    }

    private fun stopListening() {
        active = false
        handler.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        // unmute a little later so the "stop" beep is also silent
        handler.removeCallbacks(unmuteRunnable)
        handler.postDelayed(unmuteRunnable, 700)
        refreshState()
    }

    private fun listen() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r
        val mode = prefs().getString("mode", "hi_en")
        val tag = if (mode == "en") "en-IN" else "hi-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (!active) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    toast("माइक की अनुमति नहीं है")
                    stopListening()
                }
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    toast("इंटरनेट जाँचें")
                    stopListening()
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    handler.postDelayed(restartRunnable, 300)
                }
                else -> {
                    errorCount++
                    if (errorCount > 6) {
                        toast("माइक में समस्या है, दोबारा कोशिश करें")
                        stopListening()
                    } else {
                        handler.postDelayed(restartRunnable, 600)
                    }
                }
            }
        }

        override fun onResults(results: Bundle?) {
            errorCount = 0
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
            if (!text.isNullOrEmpty()) handleText(text)
            if (active) handler.postDelayed(restartRunnable, 300)
        }
    }

    // ---------- Text handling ----------

    private fun handleText(text: String) {
        // ignore the same sentence arriving twice
        val now = System.currentTimeMillis()
        if (text == lastText && now - lastTextTime < 3000) return
        lastText = text
        lastTextTime = now

        val mode = prefs().getString("mode", "hi_en")
        if (mode == "hi_en") {
            working++
            refreshState()
            pool.execute {
                val res = translateSmart(text)
                handler.post {
                    working--
                    val out = res.first
                    if (out != null) {
                        if (res.second) toast("AI से नहीं बना, साधारण अनुवाद लगाया")
                        insert(out)
                    } else {
                        toast("अनुवाद नहीं हो पाया, इंटरनेट जाँचें")
                    }
                    refreshState()
                }
            }
        } else {
            insert(clean(text))
        }
    }

    /** returns (text, usedFallbackBecauseAiFailed) */
    private fun translateSmart(q: String): Pair<String?, Boolean> {
        val key = prefs().getString("gkey", "") ?: ""
        var fallback = false
        if (key.isNotEmpty()) {
            val ai = try {
                geminiRewrite(q, key)
            } catch (e: Exception) {
                null
            }
            if (ai != null) return Pair(clean(ai), false)
            fallback = true
        }
        val plain = plainTranslate(q)
        return Pair(if (plain != null) clean(plain) else null, fallback && plain != null)
    }

    private fun clean(s: String): String {
        var t = s.replace(Regex("[“”\"«»]"), "")
        t = t.replace(Regex("(\\d)\\.(\\d)"), "$1\u0001$2")
        t = t.replace(Regex("[.,;:।–—]"), " ")
        t = t.replace("\u0001", ".")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    // ---------- Gemini: natural chat English ----------

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        if (c.responseCode != 200) throw RuntimeException("http " + c.responseCode)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun listModels(key: String): List<String> {
        models?.let { return it }
        val saved = prefs().getString("gmodel", null)
        val body = httpGet(BASE + "models?pageSize=200&key=" + URLEncoder.encode(key, "UTF-8"))
        val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
        val names = ArrayList<String>()
        val skip = Regex("tts|image|live|audio|embed|robotics|computer|thinking|exp")
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
            var ok = false
            for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
            if (!ok) continue
            val n = m.getString("name").removePrefix("models/")
            if (!n.contains("gemini") || !n.contains("flash")) continue
            if (skip.containsMatchIn(n)) continue
            names.add(n)
        }
        val lite = names.filter { it.contains("flash-lite") }.sortedDescending()
        val flash = names.filter { !it.contains("flash-lite") }.sortedDescending()
        var list: List<String> = lite + flash
        if (saved != null) list = listOf(saved) + list.filter { it != saved }
        val out = list.take(4)
        models = out
        return out
    }

    private fun geminiRewrite(hindi: String, key: String): String? {
        for (m in listModels(key)) {
            try {
                val url = URL(BASE + "models/" + m + ":generateContent?key=" + URLEncoder.encode(key, "UTF-8"))
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 10000
                c.readTimeout = 15000
                c.setRequestProperty("Content-Type", "application/json")
                val req = JSONObject()
                req.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
                req.put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", hindi)))))
                req.put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 400))
                c.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
                if (c.responseCode != 200) continue
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val parts = JSONObject(body).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
                }
                val out = sb.toString().trim()
                if (out.isNotEmpty()) {
                    prefs().edit().putString("gmodel", m).apply()
                    return out
                }
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun plainTranslate(q: String): String? {
        try {
            val body = httpGet(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=hi&tl=en&dt=t&q=" +
                    URLEncoder.encode(q, "UTF-8")
            )
            val arr: JSONArray = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).getString(0))
            val out = sb.toString().trim()
            if (out.isNotEmpty()) return out
        } catch (e: Exception) {
        }
        try {
            val body = httpGet("https://api.mymemory.translated.net/get?langpair=hi|en&q=" + URLEncoder.encode(q, "UTF-8"))
            val out = JSONObject(body).getJSONObject("responseData").getString("translatedText").trim()
            if (out.isNotEmpty()) return out
        } catch (e: Exception) {
        }
        return null
    }

    // ---------- Insert into the focused text box ----------

    private fun insert(text: String) {
        if (text.isEmpty()) return
        val focused: AccessibilityNodeInfo? = try {
            findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        } catch (ex: Exception) {
            null
        }
        val node: AccessibilityNodeInfo? = focused ?: lastNode
        if (node == null) {
            toast("पहले किसी टेक्स्ट बॉक्स पर टैप करें")
            return
        }
        node.refresh()

        val existing = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
        var s = node.textSelectionStart
        var e = node.textSelectionEnd
        if (s < 0 || e < 0 || s > existing.length || e > existing.length) {
            s = existing.length
            e = existing.length
        }
        if (s > e) {
            val t = s
            s = e
            e = t
        }
        val before = existing.substring(0, s)
        val after = existing.substring(e)
        val sep = if (before.isNotEmpty() && !before.last().isWhitespace()) " " else ""
        val ins = sep + text
        val newText = before + ins + after

        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) {
            val pos = before.length + ins.length
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("dictation", ins))
            if (!node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                toast("इस बॉक्स में टेक्स्ट नहीं डाल सका। कॉपी हो गया है, खुद पेस्ट करें।")
            }
        }
    }

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"
        private val COLOR_IDLE = Color.parseColor("#2B2F63")
        private val COLOR_LISTENING = Color.parseColor("#E8336D")
        private val COLOR_WORKING = Color.parseColor("#E0A100")

        private const val SYSTEM_PROMPT =
            "Translate the user's spoken Hindi or Hinglish into the English message a normal person would actually type while chatting, like on WhatsApp. " +
                "Stay faithful to exactly what they said: same meaning, same tone, same level of formality, nothing added and nothing removed. " +
                "Use plain everyday words, never fancy or formal ones. " +
                "Never use commas or full stops. No quotation marks. If it is a question end it with a question mark. " +
                "Output ONLY the message text."
    }
}
