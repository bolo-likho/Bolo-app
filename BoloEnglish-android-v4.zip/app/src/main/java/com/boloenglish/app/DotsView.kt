package com.boloenglish.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Small see-through disc with four tiny dots.
 * mode 0 = idle (mostly transparent), 1 = listening (dots dance), 2 = working.
 */
class DotsView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var animator: ValueAnimator? = null
    private var animating = false
    private val idleScale = floatArrayOf(0.85f, 1.2f, 1.2f, 0.85f)

    init {
        dotPaint.color = Color.argb(235, 255, 255, 255)
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = density
        ringPaint.color = Color.argb(90, 255, 255, 255)
        setMode(0)
    }

    fun setMode(m: Int) {
        discPaint.color = when (m) {
            1 -> Color.argb(215, 232, 51, 109)
            2 -> Color.argb(215, 224, 161, 0)
            else -> Color.argb(100, 0, 0, 0)
        }
        setAnimating(m != 0)
        invalidate()
    }

    private fun setAnimating(on: Boolean) {
        if (on == animating) return
        animating = on
        animator?.cancel()
        animator = null
        if (on) {
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = 900
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            a.start()
            animator = a
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val disc = w * 0.34f
        canvas.drawCircle(cx, cy, disc, discPaint)
        canvas.drawCircle(cx, cy, disc, ringPaint)

        val gap = w * 0.115f
        val base = w * 0.042f
        val startX = cx - gap * 1.5f
        for (i in 0 until 4) {
            var r = base * idleScale[i]
            var dy = 0f
            if (animating) {
                val s = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat() - i * 0.9f)
                r = base * (0.8f + 0.7f * s)
                dy = -w * 0.04f * s
            }
            canvas.drawCircle(startX + gap * i, cy + dy, r, dotPaint)
        }
    }
}
