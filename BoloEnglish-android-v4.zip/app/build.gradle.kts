plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.boloenglish.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.boloenglish.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.2"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("bolo.keystore")
            storePassword = "android"
            keyAlias = "bolo"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
