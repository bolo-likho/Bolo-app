# बोलो-लिखो (Android)

हिंदी बोलो, किसी भी ऐप में English (या हिंदी) टाइप हो जाए।

## APK बनाने के स्टेप (GitHub पर, फ्री)
1. github.com पर अकाउंट बनाओ और नया Repository बनाओ (नाम: bolo-likho, Public).
2. "uploading an existing file" पर जाकर इस फोल्डर की सारी फाइलें और फोल्डर (`.github` फोल्डर भी) ड्रैग करके अपलोड करो, फिर Commit करो।
3. ऊपर "Actions" टैब खोलो। "Build APK" चलना शुरू हो जाएगा (3-5 मिनट)।
4. हरा निशान आने पर उस रन को खोलो, नीचे "Artifacts" में `BoloEnglish-apk` डाउनलोड करो, ज़िप खोलो तो `app-debug.apk` मिलेगा।
5. APK फोन में डालकर इंस्टॉल करो ("Install unknown apps" की अनुमति देनी पड़ेगी)।
6. ऐप खोलकर स्टेप 1, 2, 3 पूरे करो।
