package com.boloenglish.app

import android.accessibilityservice.AccessibilityService
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class DictationService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()

    private var bubble: FrameLayout? = null
    private var pulse: ObjectAnimator? = null
    private var recognizer: SpeechRecognizer? = null
    private var lastNode: AccessibilityNodeInfo? = null

    private var active = false
    private var working = 0
    private var errorCount = 0

    private val hideRunnable = Runnable {
        if (!active && working == 0) removeBubble()
    }
    private val restartRunnable = Runnable {
        if (active) listen()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun prefs(): SharedPreferences = getSharedPreferences("prefs", MODE_PRIVATE)
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!::wm.isInitialized) return
        val focus: AccessibilityNodeInfo? = try {
            findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        } catch (e: Exception) {
            null
        }
        handler.removeCallbacks(hideRunnable)
        if (focus != null && focus.isEditable && !focus.isPassword) {
            lastNode = focus
            showBubble()
        } else {
            handler.postDelayed(hideRunnable, 700)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        removeBubble()
        pool.shutdownNow()
        super.onDestroy()
    }

    // ---------- Floating bubble ----------

    private fun showBubble() {
        if (bubble != null) return
        val size = dp(56)
        val frame = FrameLayout(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(COLOR_IDLE)
        frame.background = bg
        frame.elevation = dp(6).toFloat()

        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_mic)
        icon.setColorFilter(Color.WHITE)
        icon.setPadding(dp(15), dp(15), dp(15), dp(15))
        frame.addView(icon, FrameLayout.LayoutParams(size, size))

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs().getInt("bx", dm.widthPixels - size - dp(8))
        lp.y = prefs().getInt("by", (dm.heightPixels * 0.35).toInt())
        frame.setOnTouchListener(dragListener(lp))

        try {
            wm.addView(frame, lp)
        } catch (e: Exception) {
            return
        }
        bubble = frame
        refreshState()
    }

    private fun removeBubble() {
        pulse?.cancel()
        pulse = null
        val b = bubble ?: return
        try {
            wm.removeView(b)
        } catch (e: Exception) {
        }
        bubble = null
    }

    private fun dragListener(lp: WindowManager.LayoutParams): View.OnTouchListener {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        return View.OnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) dragging = true
                    if (dragging) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        prefs().edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
                    } else {
                        onBubbleTap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshState() {
        val b = bubble ?: return
        val color = when {
            active -> COLOR_LISTENING
            working > 0 -> COLOR_WORKING
            else -> COLOR_IDLE
        }
        (b.background as? GradientDrawable)?.setColor(color)
        pulse?.cancel()
        b.scaleX = 1f
        b.scaleY = 1f
        if (active) {
            val a = ObjectAnimator.ofPropertyValuesHolder(
                b,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.15f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.15f)
            )
            a.duration = 600
            a.repeatCount = ObjectAnimator.INFINITE
            a.repeatMode = ObjectAnimator.REVERSE
            a.start()
            pulse = a
        }
    }

    // ---------- Listening ----------

    private fun onBubbleTap() {
        if (active) {
            stopListening()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("पहले ऐप खोलकर माइक की अनुमति दें")
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("इस फोन में स्पीच रिकग्निशन उपलब्ध नहीं है")
            return
        }
        active = true
        errorCount = 0
        refreshState()
        listen()
    }

    private fun stopListening() {
        active = false
        handler.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        refreshState()
    }

    private fun listen() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r
        val mode = prefs().getString("mode", "hi_en")
        val tag = if (mode == "en") "en-IN" else "hi-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (!active) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    toast("माइक की अनुमति नहीं है")
                    stopListening()
                }
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    toast("इंटरनेट जाँचें")
                    stopListening()
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    handler.postDelayed(restartRunnable, 300)
                }
                else -> {
                    errorCount++
                    if (errorCount > 6) {
                        toast("माइक में समस्या है, दोबारा कोशिश करें")
                        stopListening()
                    } else {
                        handler.postDelayed(restartRunnable, 600)
                    }
                }
            }
        }

        override fun onResults(results: Bundle?) {
            errorCount = 0
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
            if (!text.isNullOrEmpty()) handleText(text)
            if (active) handler.postDelayed(restartRunnable, 300)
        }
    }

    // ---------- Text handling ----------

    private fun handleText(text: String) {
        val mode = prefs().getString("mode", "hi_en")
        if (mode == "hi_en") {
            working++
            refreshState()
            pool.execute {
                val en = translate(text)
                handler.post {
                    working--
                    if (en != null) insert(en) else toast("अनुवाद नहीं हो पाया, इंटरनेट जाँचें")
                    refreshState()
                }
            }
        } else {
            insert(text)
        }
    }

    private fun translate(q: String): String? {
        try {
            val url = URL(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=hi&tl=en&dt=t&q=" +
                    URLEncoder.encode(q, "UTF-8")
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr: JSONArray = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).getString(0))
            val out = sb.toString().trim()
            if (out.isNotEmpty()) return out
        } catch (e: Exception) {
        }
        try {
            val url = URL(
                "https://api.mymemory.translated.net/get?langpair=hi|en&q=" + URLEncoder.encode(q, "UTF-8")
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val out = JSONObject(body).getJSONObject("responseData").getString("translatedText").trim()
            if (out.isNotEmpty()) return out
        } catch (e: Exception) {
        }
        return null
    }

    private fun insert(text: String) {
        val focused: AccessibilityNodeInfo? = try {
            findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        } catch (ex: Exception) {
            null
        }
        val node: AccessibilityNodeInfo? = focused ?: lastNode
        if (node == null) {
            toast("पहले किसी टेक्स्ट बॉक्स पर टैप करें")
            return
        }
        node.refresh()

        val existing = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
        var s = node.textSelectionStart
        var e = node.textSelectionEnd
        if (s < 0 || e < 0 || s > existing.length || e > existing.length) {
            s = existing.length
            e = existing.length
        }
        if (s > e) {
            val t = s
            s = e
            e = t
        }
        val before = existing.substring(0, s)
        val after = existing.substring(e)
        val sep = if (before.isNotEmpty() && !before.last().isWhitespace()) " " else ""
        val ins = sep + text
        val newText = before + ins + after

        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) {
            val pos = before.length + ins.length
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("dictation", ins))
            if (!node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                toast("इस बॉक्स में टेक्स्ट नहीं डाल सका। कॉपी हो गया है, खुद पेस्ट करें।")
            }
        }
    }

    companion object {
        private val COLOR_IDLE = Color.parseColor("#C2255C")
        private val COLOR_LISTENING = Color.parseColor("#1F8F55")
        private val COLOR_WORKING = Color.parseColor("#E0A100")
    }
}
