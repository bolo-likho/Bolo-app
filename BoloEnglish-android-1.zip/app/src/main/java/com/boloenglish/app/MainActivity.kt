package com.boloenglish.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var micStatus: TextView
    private lateinit var svcStatus: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, bold: Boolean = false, color: Int = Color.parseColor("#1D2145")): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(6), 0, dp(6))
        return tv
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(20)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("बोलो-लिखो", 28f, true))
        root.addView(label("किसी भी ऐप में टेक्स्ट बॉक्स पर टैप करने पर एक माइक बटन दिखेगा। उसे दबाकर बोलिए, टेक्स्ट सीधे उसी बॉक्स में लिख जाएगा।", 15f))

        root.addView(label("स्टेप 1: माइक की अनुमति", 18f, true))
        micStatus = label("", 15f)
        root.addView(micStatus)
        root.addView(button("माइक की अनुमति दें") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })

        root.addView(label("स्टेप 2: Accessibility चालू करें", 18f, true))
        svcStatus = label("", 15f)
        root.addView(svcStatus)
        root.addView(button("Accessibility सेटिंग खोलें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(label("वहाँ \"बोलो-लिखो\" ढूँढकर उसे ON करें। अगर बटन ग्रे (बंद) दिखे: फोन की Settings > Apps > बोलो-लिखो > ऊपर तीन बिंदु (⋮) > \"Allow restricted settings\" दबाएँ, फिर दोबारा कोशिश करें।", 13f, false, Color.parseColor("#666B8C")))

        root.addView(label("स्टेप 3: भाषा चुनें", 18f, true))
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val modes = listOf(
            "hi_en" to "हिंदी बोलो → English लिखो",
            "hi" to "हिंदी बोलो → हिंदी लिखो",
            "en" to "English बोलो → English लिखो"
        )
        val group = RadioGroup(this)
        val current = prefs.getString("mode", "hi_en")
        modes.forEachIndexed { idx, pair ->
            val rb = RadioButton(this)
            rb.id = 1000 + idx
            rb.text = pair.second
            rb.textSize = 16f
            group.addView(rb)
            if (pair.first == current) group.check(rb.id)
        }
        group.setOnCheckedChangeListener { _, id ->
            val idx = id - 1000
            if (idx in modes.indices) prefs.edit().putString("mode", modes[idx].first).apply()
        }
        root.addView(group)

        root.addView(label("यहाँ टेस्ट करें", 18f, true))
        val test = EditText(this)
        test.hint = "यहाँ टैप करें, फिर माइक बटन दबाकर बोलें"
        test.minLines = 3
        test.gravity = Gravity.TOP or Gravity.START
        test.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        root.addView(test)

        root.addView(label("नोट: बोलना पहचानने और अनुवाद के लिए इंटरनेट चाहिए। माइक बटन को पकड़कर खिसकाया जा सकता है।", 13f, false, Color.parseColor("#666B8C")))
    }

    override fun onResume() {
        super.onResume()
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        micStatus.text = if (micOk) "✅ माइक की अनुमति मिल गई" else "❌ अनुमति बाकी है"

        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val cls = DictationService::class.java
        val svcOk = enabled.contains(packageName + "/" + cls.name) ||
            enabled.contains(packageName + "/." + cls.simpleName)
        svcStatus.text = if (svcOk) "✅ सेवा चालू है" else "❌ सेवा बंद है"
    }
}
